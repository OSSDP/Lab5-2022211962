
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '学生',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'studentNo',
        name: "{{studentNo_0af60b29_yp6z}}",
        binding: 'studentNo',
        updateOn: 'blur',
        defaultI18nValue: '学号',
    })
    studentNo: FormControl;

    @NgFormControl({
        id: 'fullName',
        name: "{{fullName_affd0c98_fdxp}}",
        binding: 'fullName',
        updateOn: 'blur',
        defaultI18nValue: '姓名',
    })
    fullName: FormControl;

    @NgFormControl({
        id: 'gender',
        name: "{{gender_79cb3960_3qma}}",
        binding: 'gender',
        updateOn: 'change',
        defaultI18nValue: '性别',
    })
    gender: FormControl;

    @NgFormControl({
        id: 'birthday',
        name: "{{birthday_80a91865_2nvx}}",
        binding: 'birthday',
        updateOn: 'blur',
        valueConverter: new DateConverter('yyyy-MM-dd'),
        defaultI18nValue: '出生日期',
    })
    birthday: FormControl;

    @NgFormControl({
        id: 'area',
        name: "{{area_1978d155_j5xh}}",
        binding: 'area',
        updateOn: 'blur',
        defaultI18nValue: '地区',
    })
    area: FormControl;

}