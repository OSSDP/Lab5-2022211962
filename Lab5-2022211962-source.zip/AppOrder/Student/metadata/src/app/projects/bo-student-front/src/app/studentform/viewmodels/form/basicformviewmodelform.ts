
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '学生',
    enableValidate: true
})

@Injectable()
export class BasicFormViewmodelForm extends Form {
    @NgFormControl({
        id: 'studentNo_93357987_f2ja',
        name: "{{studentNo_93357987_f2ja}}",
        binding: 'studentNo',
        updateOn: 'blur',
        defaultI18nValue: '学号',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    studentNo: FormControl;

    @NgFormControl({
        id: 'fullName_a262c945_7zb5',
        name: "{{fullName_a262c945_7zb5}}",
        binding: 'fullName',
        updateOn: 'blur',
        defaultI18nValue: '姓名',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    fullName: FormControl;

    @NgFormControl({
        id: 'gender_bd9e2870_pc6h',
        name: "{{gender_bd9e2870_pc6h}}",
        binding: 'gender',
        updateOn: 'change',
        defaultI18nValue: '性别',
    })
    gender: FormControl;

    @NgFormControl({
        id: 'birthday_3533e3de_cw1o',
        name: "{{birthday_3533e3de_cw1o}}",
        binding: 'birthday',
        updateOn: 'blur',
        valueConverter: new DateConverter('yyyy-MM-dd'),
        defaultI18nValue: '出生日期',
    })
    birthday: FormControl;

    @NgFormControl({
        id: 'area_0ddc2e43_ahgx',
        name: "{{area_0ddc2e43_ahgx}}",
        binding: 'area',
        updateOn: 'blur',
        defaultI18nValue: '地区',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    area: FormControl;

}