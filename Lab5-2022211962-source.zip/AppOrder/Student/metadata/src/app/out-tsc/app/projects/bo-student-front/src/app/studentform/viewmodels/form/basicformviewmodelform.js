import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'studentNo_93357987_f2ja',
            name: "{{studentNo_93357987_f2ja}}",
            binding: 'studentNo',
            updateOn: 'blur',
            defaultI18nValue: '学号',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "studentNo", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'fullName_a262c945_7zb5',
            name: "{{fullName_a262c945_7zb5}}",
            binding: 'fullName',
            updateOn: 'blur',
            defaultI18nValue: '姓名',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "fullName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'gender_bd9e2870_pc6h',
            name: "{{gender_bd9e2870_pc6h}}",
            binding: 'gender',
            updateOn: 'change',
            defaultI18nValue: '性别',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "gender", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'birthday_3533e3de_cw1o',
            name: "{{birthday_3533e3de_cw1o}}",
            binding: 'birthday',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '出生日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "birthday", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'area_0ddc2e43_ahgx',
            name: "{{area_0ddc2e43_ahgx}}",
            binding: 'area',
            updateOn: 'blur',
            defaultI18nValue: '地区',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "area", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '学生',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
