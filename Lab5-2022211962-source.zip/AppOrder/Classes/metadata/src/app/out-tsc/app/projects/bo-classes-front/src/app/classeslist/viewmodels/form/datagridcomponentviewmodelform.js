import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'classesNo',
            name: "{{classesNo_36d70be2_kfez}}",
            binding: 'classesNo',
            updateOn: 'blur',
            defaultI18nValue: '班级编码',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "classesNo", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'name',
            name: "{{name_b686a537_wxfk}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'grade',
            name: "{{grade_c8656f99_bovn}}",
            binding: 'grade',
            updateOn: 'change',
            defaultI18nValue: '年级',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "grade", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'numbers',
            name: "{{numbers_a721fa54_dpqy}}",
            binding: 'numbers',
            updateOn: 'blur',
            defaultI18nValue: '人数',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "numbers", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '班级',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
