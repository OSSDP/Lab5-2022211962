import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'classesNo_19a56de0_nxk4',
            name: "{{classesNo_19a56de0_nxk4}}",
            binding: 'classesNo',
            updateOn: 'blur',
            defaultI18nValue: '班级编码',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "classesNo", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'name_938971b9_be7e',
            name: "{{name_938971b9_be7e}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '名称',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'grade_c01d0433_03mc',
            name: "{{grade_c01d0433_03mc}}",
            binding: 'grade',
            updateOn: 'change',
            defaultI18nValue: '年级',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "grade", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'numbers_f7b2194e_lxae',
            name: "{{numbers_f7b2194e_lxae}}",
            binding: 'numbers',
            updateOn: 'blur',
            defaultI18nValue: '人数',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "numbers", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '班级',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
