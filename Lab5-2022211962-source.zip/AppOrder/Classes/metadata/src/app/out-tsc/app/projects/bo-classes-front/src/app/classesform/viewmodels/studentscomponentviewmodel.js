import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ViewModel, NgCommand } from '@farris/devkit';
import { Observable } from 'rxjs';
var ɵ0 = { type: 'string' };
var StudentsComponentViewmodel = /** @class */ (function (_super) {
    tslib_1.__extends(StudentsComponentViewmodel, _super);
    function StudentsComponentViewmodel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bindingPath = '/studentss';
        _this.dom = {
            "dataGrid_students": {
                "type": "DataGrid",
                "resourceId": "dataGrid_students",
                "visible": {
                    "useQuote": false,
                    "isExpression": false,
                    "value": true
                },
                "id": "dataGrid_students",
                "size": {},
                "readonly": {
                    "useQuote": false,
                    "isExpression": false,
                    "value": false
                },
                "fields": [
                    {
                        "type": "GridField",
                        "resourceId": "student_Student_StudentNo_fdca4eaa_4555",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "student_Student_StudentNo_fdca4eaa_4555",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "student_Student_StudentNo",
                            "fullPath": "Student.Student_StudentNo",
                            "isExpression": false,
                            "value": "student_Student_StudentNo"
                        },
                        "dataField": "student.student_StudentNo",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "学号",
                        "editor": {
                            "type": "LookupEdit",
                            "isTextArea": true,
                            "resourceId": "student_Student_StudentNo_fdca4eaa_nf6e",
                            "defaultI18nValue": "学号",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "student_Student_StudentNo_fdca4eaa_nf6e",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "student_Student_StudentNo",
                                "fullPath": "Student.Student_StudentNo",
                                "isExpression": false,
                                "value": "student_Student_StudentNo"
                            },
                            "disable": false,
                            "dataSource": {
                                "uri": "Students.student_Student_StudentNo",
                                "displayName": "学生帮助",
                                "idField": "id",
                                "type": "ViewObject",
                                "helpCode": "StudentLookup"
                            },
                            "valueField": "id",
                            "textField": "studentNo",
                            "multiSelect": false,
                            "pageSize": 20,
                            "mapFields": {
                                "id": "student.student",
                                "studentNo": "student.student_StudentNo",
                                "fullName": "student.student_FullName"
                            },
                            "displayType": "List",
                            "enableExtendLoadMethod": true,
                            "editable": false,
                            "noSearch": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "useTip": false,
                            "useFavorite": true,
                            "enableToSelect": true,
                            "isRecordSize": false,
                            "expandLevel": -1,
                            "enableFullTree": false,
                            "context": {
                                "enableExtendLoadMethod": true
                            },
                            "loadTreeDataType": "default",
                            "enableClear": true,
                            "enableCascade": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "student_Student_FullName_d3e582c6_y0gi",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "student_Student_FullName_d3e582c6_y0gi",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "student_Student_FullName",
                            "fullPath": "Student.Student_FullName",
                            "isExpression": false,
                            "value": "student_Student_FullName"
                        },
                        "dataField": "student.student_FullName",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "姓名",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "student_Student_FullName_d3e582c6_oj8k",
                            "defaultI18nValue": "姓名",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "student_Student_FullName_d3e582c6_oj8k",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "student_Student_FullName",
                                "isExpression": false,
                                "value": "student_Student_FullName"
                            },
                            "disable": false,
                            "maxLength": 36,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "job_10b60ce7_tj26",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "job_10b60ce7_tj26",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "job",
                            "fullPath": "Job",
                            "isExpression": false,
                            "value": "job"
                        },
                        "dataField": "job",
                        "dataType": "enum",
                        "multiLanguage": false,
                        "caption": "职位",
                        "editor": {
                            "type": "ComboList",
                            "isTextArea": true,
                            "resourceId": "job_10b60ce7_ke7p",
                            "defaultI18nValue": "职位",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "job_10b60ce7_ke7p",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "job",
                                "isExpression": false,
                                "value": "job"
                            },
                            "disable": false,
                            "editable": false,
                            "idField": "value",
                            "textField": "name",
                            "multiSelect": false,
                            "data": [
                                {
                                    "disabled": false,
                                    "name": "班长",
                                    "value": "1"
                                },
                                {
                                    "disabled": false,
                                    "name": "体育委员",
                                    "value": "2"
                                },
                                {
                                    "disabled": false,
                                    "name": "学生",
                                    "value": "3"
                                }
                            ],
                            "autoWidth": true
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "resizeable": true,
                        "enumData": [
                            {
                                "disabled": false,
                                "name": "班长",
                                "value": "1"
                            },
                            {
                                "disabled": false,
                                "name": "体育委员",
                                "value": "2"
                            },
                            {
                                "disabled": false,
                                "name": "学生",
                                "value": "3"
                            }
                        ],
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "change",
                        "formatter": {
                            "type": "none"
                        }
                    }
                ],
                "multiSelect": false,
                "editable": "viewModel.stateMachine['editable']",
                "showLineNumber": false,
                "lineNumberTitle": "#",
                "groupTotalText": "Total",
                "filterable": false,
                "groupable": false,
                "rowClass": ""
            }
        };
        return _this;
    }
    StudentsComponentViewmodel.prototype.studentsAddItem1 = function (commandParam) { return; };
    StudentsComponentViewmodel.prototype.studentsRemoveItem1 = function (commandParam) { return; };
    tslib_1.__decorate([
        NgCommand({
            name: 'studentsAddItem1',
            params: {}
        }),
        tslib_1.__metadata("design:type", Function),
        tslib_1.__metadata("design:paramtypes", [Object]),
        tslib_1.__metadata("design:returntype", Observable)
    ], StudentsComponentViewmodel.prototype, "studentsAddItem1", null);
    tslib_1.__decorate([
        NgCommand({
            name: 'studentsRemoveItem1',
            params: {
                id: '{DATA~/#{students-component}/studentss/id}'
            },
            paramDescriptions: {
                id: ɵ0
            }
        }),
        tslib_1.__metadata("design:type", Function),
        tslib_1.__metadata("design:paramtypes", [Object]),
        tslib_1.__metadata("design:returntype", Observable)
    ], StudentsComponentViewmodel.prototype, "studentsRemoveItem1", null);
    StudentsComponentViewmodel = tslib_1.__decorate([
        Injectable()
    ], StudentsComponentViewmodel);
    return StudentsComponentViewmodel;
}(ViewModel));
export { StudentsComponentViewmodel };
export { ɵ0 };
