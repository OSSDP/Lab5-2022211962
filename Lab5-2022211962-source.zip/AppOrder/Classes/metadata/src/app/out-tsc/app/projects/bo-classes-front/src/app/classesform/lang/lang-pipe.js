import * as tslib_1 from "tslib";
import { Pipe, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
export function createTranslateLoader(http, version) {
    var versionSuffix = "";
    if (version) {
        versionSuffix = "?v=" + version;
    }
    return new TranslateHttpLoader(http, '/apps/apporder/df/web/bo-classes-front/classesform/i18n/', '.json' + versionSuffix);
}
export var lang = { "zh-CHS": { "root-component": "", "root-layout": "", "page-header": "", "header-nav": "", "header-title-container": "", "page-header-title": "", "title": "班级表单", "page-header-toolbar": "", "button-add": "新增", "button-edit": "编辑", "button-save": "保存", "button-cancel": "取消", "main-container": "", "like-card-container": "", "basic-form-component-ref": "", "detail-container": "", "detail-section": "", "Section/detail-section/mainTitle": "", "Section/detail-section/subTitle": "", "detail-tab": "", "students-tab-page": "学生", "students-component-ref": "", "students-tab-toolbar": "", "studentsAddButton": "新增", "studentsRemoveButton": "删除", "basic-form-component": "", "basic-form-section": "", "Section/basic-form-section/mainTitle": "基本信息", "Section/basic-form-section/subTitle": "", "basic-form-layout": "", "classesNo_19a56de0_nxk4": "班级编码", "TextBox/classesNo_19a56de0_nxk4/placeHolder": "", "name_938971b9_be7e": "名称", "TextBox/name_938971b9_be7e/placeHolder": "", "grade_c01d0433_03mc": "年级", "EnumField/grade_c01d0433_03mc/placeHolder": "", "EnumField/grade_c01d0433_03mc/enumData/One": "一年级", "EnumField/grade_c01d0433_03mc/enumData/Two": "二年级", "EnumField/grade_c01d0433_03mc/enumData/Three": "三年级", "numbers_f7b2194e_lxae": "人数", "NumberSpinner/numbers_f7b2194e_lxae/placeHolder": "", "students-component": "", "students-component-layout": "", "dataGrid_students": "", "DataGrid/dataGrid_students/lineNumberTitle": "", "DataGrid/dataGrid_students/OperateEditButton": "编辑", "DataGrid/dataGrid_students/OperateDeleteButton": "删除", "DataGrid/dataGrid_students/OperateColumn": "操作", "student_Student_StudentNo_fdca4eaa_4555": "学号", "GridField/student_Student_StudentNo_fdca4eaa_4555/editor/student_Student_StudentNo_fdca4eaa_nf6e": "学号", "GridField/student_Student_StudentNo_fdca4eaa_4555/editor/LookupEdit/student_Student_StudentNo_fdca4eaa_nf6e/placeHolder": "", "GridField/student_Student_StudentNo_fdca4eaa_4555/editor/LookupEdit/student_Student_StudentNo_fdca4eaa_nf6e/dialogTitle": "", "student_Student_FullName_d3e582c6_y0gi": "姓名", "GridField/student_Student_FullName_d3e582c6_y0gi/editor/student_Student_FullName_d3e582c6_oj8k": "姓名", "GridField/student_Student_FullName_d3e582c6_y0gi/editor/TextBox/student_Student_FullName_d3e582c6_oj8k/placeHolder": "", "job_10b60ce7_tj26": "职位", "GridField/job_10b60ce7_tj26/enumData/1": "班长", "GridField/job_10b60ce7_tj26/enumData/2": "体育委员", "GridField/job_10b60ce7_tj26/enumData/3": "学生" } };
var LangPipe = /** @class */ (function () {
    function LangPipe(translate, http) {
        this.translate = translate;
        this.http = http;
    }
    LangPipe.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangPipe = tslib_1.__decorate([
        Pipe({ name: 'lang' }),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], LangPipe);
    return LangPipe;
}());
export { LangPipe };
var SafeHtmlPipe = /** @class */ (function () {
    function SafeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SafeHtmlPipe.prototype.transform = function (url) {
        if (!url) {
            url = "";
        }
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    };
    SafeHtmlPipe = tslib_1.__decorate([
        Pipe({ name: 'safeHtml' }),
        tslib_1.__metadata("design:paramtypes", [DomSanitizer])
    ], SafeHtmlPipe);
    return SafeHtmlPipe;
}());
export { SafeHtmlPipe };
var LangService = /** @class */ (function () {
    function LangService(translate) {
        this.translate = translate;
    }
    LangService.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangService.prototype.getCurrentLanguage = function () {
        return this.translate.currentLang;
    };
    LangService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService])
    ], LangService);
    return LangService;
}());
export { LangService };
var TranslateResolveService = /** @class */ (function () {
    function TranslateResolveService(translate, http) {
        this.translate = translate;
        this.http = http;
        translate.defaultLang = 'zh-CHS';
        translate.setTranslation('zh-CHS', lang['zh-CHS']);
    }
    TranslateResolveService.prototype.resolve = function (route, state) {
        var _this = this;
        var langCode = localStorage.getItem('languageCode');
        if (!langCode) {
            langCode = "zh-CHS";
        }
        if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http, null))) {
            this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
            return of(this.translate[langCode]);
        }
        else {
            var httpOb = this.http.get("/apps/apporder/df/web/bo-classes-front/version.json?v=" + new Date().getTime()).pipe(switchMap(function (data) {
                var currentVersion = null;
                if (data instanceof Array) {
                    var versionKey_1 = "classesform/" + langCode + ".json";
                    data.forEach(function (item) {
                        if (item.category == "i18n" && item.key == versionKey_1) {
                            currentVersion = item.value;
                        }
                    });
                }
                _this.translate.defaultLang = langCode;
                _this.translate.currentLang = langCode;
                _this.translate.currentLoader = createTranslateLoader(_this.http, currentVersion);
                var tran = _this.translate.getTranslation(langCode).pipe(catchError(function (err) {
                    console.error("read resource file failed,please check!!! " + err);
                    return of(err);
                }));
                return tran;
            }));
            return httpOb;
        }
    };
    TranslateResolveService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], TranslateResolveService);
    return TranslateResolveService;
}());
export { TranslateResolveService };
