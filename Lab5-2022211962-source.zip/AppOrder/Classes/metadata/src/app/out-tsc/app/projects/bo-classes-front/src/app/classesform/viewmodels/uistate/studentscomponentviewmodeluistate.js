import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var StudentsComponentViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(StudentsComponentViewmodelUIState, _super);
    function StudentsComponentViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    StudentsComponentViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], StudentsComponentViewmodelUIState);
    return StudentsComponentViewmodelUIState;
}(UIState));
export { StudentsComponentViewmodelUIState };
