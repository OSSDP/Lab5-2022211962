import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var StudentsComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(StudentsComponentViewmodelForm, _super);
    function StudentsComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'student.student_StudentNo',
            name: "{{student_Student_StudentNo_fdca4eaa_4555}}",
            binding: 'student.student_StudentNo',
            updateOn: 'blur',
            defaultI18nValue: '学号',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], StudentsComponentViewmodelForm.prototype, "student_Student_StudentNo", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'student.student_FullName',
            name: "{{student_Student_FullName_d3e582c6_y0gi}}",
            binding: 'student.student_FullName',
            updateOn: 'blur',
            defaultI18nValue: '姓名',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], StudentsComponentViewmodelForm.prototype, "student_Student_FullName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'job',
            name: "{{job_10b60ce7_tj26}}",
            binding: 'job',
            updateOn: 'change',
            defaultI18nValue: '职位',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], StudentsComponentViewmodelForm.prototype, "job", void 0);
    StudentsComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '学生',
            enableValidate: true
        }),
        Injectable()
    ], StudentsComponentViewmodelForm);
    return StudentsComponentViewmodelForm;
}(Form));
export { StudentsComponentViewmodelForm };
