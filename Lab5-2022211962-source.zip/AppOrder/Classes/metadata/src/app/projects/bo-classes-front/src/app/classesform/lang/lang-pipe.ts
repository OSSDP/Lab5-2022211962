
import { Pipe, PipeTransform, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer} from '@angular/platform-browser';
export function createTranslateLoader(http: HttpClient,version:string) {
  let versionSuffix = "";
  if (version) {
    versionSuffix = "?v=" + version;
  }
  return new TranslateHttpLoader(http, '/apps/apporder/df/web/bo-classes-front/classesform/i18n/', '.json'+ versionSuffix);
}

export let lang = {"zh-CHS":{"root-component":"","root-layout":"","page-header":"","header-nav":"","header-title-container":"","page-header-title":"","title":"班级表单","page-header-toolbar":"","button-add":"新增","button-edit":"编辑","button-save":"保存","button-cancel":"取消","main-container":"","like-card-container":"","basic-form-component-ref":"","detail-container":"","detail-section":"","Section/detail-section/mainTitle":"","Section/detail-section/subTitle":"","detail-tab":"","students-tab-page":"学生","students-component-ref":"","students-tab-toolbar":"","studentsAddButton":"新增","studentsRemoveButton":"删除","basic-form-component":"","basic-form-section":"","Section/basic-form-section/mainTitle":"基本信息","Section/basic-form-section/subTitle":"","basic-form-layout":"","classesNo_19a56de0_nxk4":"班级编码","TextBox/classesNo_19a56de0_nxk4/placeHolder":"","name_938971b9_be7e":"名称","TextBox/name_938971b9_be7e/placeHolder":"","grade_c01d0433_03mc":"年级","EnumField/grade_c01d0433_03mc/placeHolder":"","EnumField/grade_c01d0433_03mc/enumData/One":"一年级","EnumField/grade_c01d0433_03mc/enumData/Two":"二年级","EnumField/grade_c01d0433_03mc/enumData/Three":"三年级","numbers_f7b2194e_lxae":"人数","NumberSpinner/numbers_f7b2194e_lxae/placeHolder":"","students-component":"","students-component-layout":"","dataGrid_students":"","DataGrid/dataGrid_students/lineNumberTitle":"","DataGrid/dataGrid_students/OperateEditButton":"编辑","DataGrid/dataGrid_students/OperateDeleteButton":"删除","DataGrid/dataGrid_students/OperateColumn":"操作","student_Student_StudentNo_fdca4eaa_4555":"学号","GridField/student_Student_StudentNo_fdca4eaa_4555/editor/student_Student_StudentNo_fdca4eaa_nf6e":"学号","GridField/student_Student_StudentNo_fdca4eaa_4555/editor/LookupEdit/student_Student_StudentNo_fdca4eaa_nf6e/placeHolder":"","GridField/student_Student_StudentNo_fdca4eaa_4555/editor/LookupEdit/student_Student_StudentNo_fdca4eaa_nf6e/dialogTitle":"","student_Student_FullName_d3e582c6_y0gi":"姓名","GridField/student_Student_FullName_d3e582c6_y0gi/editor/student_Student_FullName_d3e582c6_oj8k":"姓名","GridField/student_Student_FullName_d3e582c6_y0gi/editor/TextBox/student_Student_FullName_d3e582c6_oj8k/placeHolder":"","job_10b60ce7_tj26":"职位","GridField/job_10b60ce7_tj26/enumData/1":"班长","GridField/job_10b60ce7_tj26/enumData/2":"体育委员","GridField/job_10b60ce7_tj26/enumData/3":"学生"}};

@Pipe({ name: 'lang' })
export class LangPipe implements PipeTransform {
  constructor(private translate: TranslateService, private http: HttpClient) { }
  transform(key: string, langCode: string, defaultValue?: string) {
      
    const translateValue = this.translate.instant(key);
    if (translateValue == "JitI18nDefaultValue") {
      return defaultValue ? defaultValue : "";
    }

    return translateValue;
  }
}
@Pipe({ name: 'safeHtml' })
export class SafeHtmlPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) { }
  transform(url) {
    if (!url) {
      url = "";
    }
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
@Injectable()
export class LangService {
  constructor(private translate: TranslateService) { }
  transform(key: string, langCode: string, defaultValue?: string) {
    
    const translateValue = this.translate.instant(key);
    if (translateValue == "JitI18nDefaultValue") {
      return defaultValue ? defaultValue : "";
    }

    return translateValue;
  }

  getCurrentLanguage() {
    return this.translate.currentLang;
  }

}

@Injectable()
export class TranslateResolveService implements Resolve<any>{

  constructor(private translate: TranslateService, private http: HttpClient) {
    translate.defaultLang = 'zh-CHS';
    translate.setTranslation('zh-CHS', lang['zh-CHS']);
  }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
    let langCode = localStorage.getItem('languageCode');
    if (!langCode) {
      langCode = "zh-CHS";
    }
    if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http,null))) {
      this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
      return of(this.translate[langCode]);
    } else {
      const httpOb = this.http.get("/apps/apporder/df/web/bo-classes-front/version.json?v=" + new Date().getTime()).pipe(switchMap((data)=>{
        let currentVersion = null;
        if (data instanceof Array) {
          const versionKey = "classesform/" + langCode + ".json";
          data.forEach((item) => {
            if (item.category == "i18n" && item.key == versionKey) {
              currentVersion = item.value;
            }
          });
        }

        this.translate.defaultLang = langCode;
        this.translate.currentLang = langCode;
        this.translate.currentLoader = createTranslateLoader(this.http, currentVersion);

    let tran = this.translate.getTranslation(langCode).pipe(catchError(err => {
      console.error("read resource file failed,please check!!! "+ err);
      return of(err);
    }));
    return tran;
      }));
      return httpOb;
    }
  }
}
