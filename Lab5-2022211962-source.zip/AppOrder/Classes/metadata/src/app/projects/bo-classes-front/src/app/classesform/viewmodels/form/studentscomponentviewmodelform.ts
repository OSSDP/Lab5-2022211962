
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '学生',
    enableValidate: true
})

@Injectable()
export class StudentsComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'student.student_StudentNo',
        name: "{{student_Student_StudentNo_fdca4eaa_4555}}",
        binding: 'student.student_StudentNo',
        updateOn: 'blur',
        defaultI18nValue: '学号',
    })
    student_Student_StudentNo: FormControl;

    @NgFormControl({
        id: 'student.student_FullName',
        name: "{{student_Student_FullName_d3e582c6_y0gi}}",
        binding: 'student.student_FullName',
        updateOn: 'blur',
        defaultI18nValue: '姓名',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    student_Student_FullName: FormControl;

    @NgFormControl({
        id: 'job',
        name: "{{job_10b60ce7_tj26}}",
        binding: 'job',
        updateOn: 'change',
        defaultI18nValue: '职位',
    })
    job: FormControl;

}