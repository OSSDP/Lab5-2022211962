
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '班级',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'classesNo',
        name: "{{classesNo_36d70be2_kfez}}",
        binding: 'classesNo',
        updateOn: 'blur',
        defaultI18nValue: '班级编码',
    })
    classesNo: FormControl;

    @NgFormControl({
        id: 'name',
        name: "{{name_b686a537_wxfk}}",
        binding: 'name',
        updateOn: 'blur',
        defaultI18nValue: '名称',
    })
    name: FormControl;

    @NgFormControl({
        id: 'grade',
        name: "{{grade_c8656f99_bovn}}",
        binding: 'grade',
        updateOn: 'change',
        defaultI18nValue: '年级',
    })
    grade: FormControl;

    @NgFormControl({
        id: 'numbers',
        name: "{{numbers_a721fa54_dpqy}}",
        binding: 'numbers',
        updateOn: 'blur',
        defaultI18nValue: '人数',
    })
    numbers: FormControl;

}