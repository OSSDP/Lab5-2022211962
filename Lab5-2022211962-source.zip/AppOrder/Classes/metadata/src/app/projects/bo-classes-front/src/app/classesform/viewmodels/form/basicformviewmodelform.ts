
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '班级',
    enableValidate: true
})

@Injectable()
export class BasicFormViewmodelForm extends Form {
    @NgFormControl({
        id: 'classesNo_19a56de0_nxk4',
        name: "{{classesNo_19a56de0_nxk4}}",
        binding: 'classesNo',
        updateOn: 'blur',
        defaultI18nValue: '班级编码',
        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    classesNo: FormControl;

    @NgFormControl({
        id: 'name_938971b9_be7e',
        name: "{{name_938971b9_be7e}}",
        binding: 'name',
        updateOn: 'blur',
        defaultI18nValue: '名称',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    name: FormControl;

    @NgFormControl({
        id: 'grade_c01d0433_03mc',
        name: "{{grade_c01d0433_03mc}}",
        binding: 'grade',
        updateOn: 'change',
        defaultI18nValue: '年级',
    })
    grade: FormControl;

    @NgFormControl({
        id: 'numbers_f7b2194e_lxae',
        name: "{{numbers_f7b2194e_lxae}}",
        binding: 'numbers',
        updateOn: 'blur',
        defaultI18nValue: '人数',
    })
    numbers: FormControl;

}