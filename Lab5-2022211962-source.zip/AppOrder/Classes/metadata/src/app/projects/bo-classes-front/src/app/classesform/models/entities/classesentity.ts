
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';
import { StudentsEntity } from './studentsentity';

@NgEntity({
    originalCode: "Classes",
    nodeCode: "classess"
})
export class ClassesEntity extends Entity {

    @NgField({
        originalDataField: 'ID',
        dataField: 'id',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ID',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    id: string;

    @NgField({
        originalDataField: 'Version',
        dataField: 'version',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'Version',
        enableTimeZone: true,
    })
    version: string;

    @NgField({
        originalDataField: 'ClassesNo',
        dataField: 'classesNo',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ClassesNo',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    classesNo: string;

    @NgField({
        originalDataField: 'Name',
        dataField: 'name',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Name',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    name: string;

    @NgField({
        originalDataField: 'Grade',
        dataField: 'grade',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: 'One',
        path: 'Grade',
    })
    grade: any;

    @NgField({
        originalDataField: 'Numbers',
        dataField: 'numbers',
        originalDataFieldType: 'Number',
        initValue: 0,
        path: 'Numbers',
    })
    numbers: any;

    @NgList({
        dataField: 'studentss',
        originalDataField: '',
        type: StudentsEntity

    })

    studentss: EntityList<StudentsEntity>;
}